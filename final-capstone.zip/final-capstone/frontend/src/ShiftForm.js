import React from 'react';
import { Select, InputNumber, Row, Col, Form, Input, Cascader, Button } from 'antd';
import axios from 'axios';
import './App.css';

const Option = Select.Option;
const FormItem = Form.Item;
const InputGroup = Input.Group;


class ShiftForm extends React.Component{
    constructor (){
        super();
        this.state = {
            name: '',
            position: '',
            points: 0,
            tipsEarned: 0
        }
        this.empData = this.empData.bind(this);
        this.changeHandler = this.changeHandler.bind(this);
        this.changeEmpHandler = this.changeEmpHandler.bind(this);
    }


    empData (event){
        event.preventDefault();
        let emp = this.state;
        this.props.formSubmit(emp);
        event.target.value=''
    }

    changeHandler=(value,key)=> {
        this.setState({
            [key]: value
        });
    }
    changeEmpHandler(value, key) {
        let emp_id = this.props.name.filter(emp =>{
            return emp.name === value
        }).reduce((acc,cur)=>{return acc + cur.id},'')

        this.setState({
            [key]: value
        },()=>{
            axios.post('http://localhost:8080/position', {id: emp_id})
            .then((result)=>{
                this.setState({
                    position: result.data.name,
                    points: result.data.maxPoints
                })
            })
                .catch(err =>{
                    console.log(err)
                })
        }
    );
    }



    render(){
        
    let empList = this.props.name.map((curr, i)=>{
        return <Option key={curr.name}>{curr.name}</Option>
        })
    
    let posList = this.props.position.map((curr, i)=>{
        return <Option key={curr.name}>{curr.name}</Option>
    })
        return(
            
               
                    <Form layout="inline horizontal" onSubmit={this.empData}>
                        <InputGroup>
                            <Row type="flex" justify="left">
                                <Col span={8} offset={1}>
                                    <FormItem style={{width: "80%"}}><span className="label"> Enter Name</span>
                                            <Select style={{width: "60%"}} size="large" placeholder="Employee" onChange={val=>this.changeEmpHandler(val,'name')}
                                            >
                                                {empList}
                                            </Select>
                                        
                                    </FormItem>
                                    </Col>
                                    <Col span={8}>
                                        <FormItem  > <span className="label"> Enter Tips $</span>
                                            <InputNumber defaultValue ={0} min={0} style={{width: "40%"}} size="large" placeholder="Enter Tips" onChange={val =>this.changeHandler(val, 'tipsEarned')} />
                                        </FormItem>
                                    </Col> 
                                    <Col span={4} offset={2} style={{paddingRight: '2vw'}}>  
                                        <Button size="large" htmlType="submit" type="ghost"
                                        className="label"> Submit</Button>
                                    </Col>
                            </Row>
                        </InputGroup>
                    </Form>
               
            
        )
    }
};

export default ShiftForm;