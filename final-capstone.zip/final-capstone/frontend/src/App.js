import React, { Component } from 'react';
import axios from 'axios';
import {BrowserRouter as Router, Link, Route, Switch} from 'react-router-dom';
import './App.css';
import Nav from './Nav';

import CreateEmp from './CreateEmp';
import StartShift from './StartShift';
const moment =require('moment');

class App extends React.Component {
    constructor (){
      super();
      this.state ={
        value: moment().format("dddd, MMMM Do YYYY, h:mm a")
      }
    }

    componentDidMount(){
        axios.get('http://localhost:8080/positions')
        .then((results)=>{
          console.log(results)
          this.setState({
            position: results.data
          })
        })
        .catch((err)=>{
          console.log(err)
        })
        this.clock();
    }

    clock = ()=>{
      setTimeout(()=>{
        this.setState({
          value: moment().format("dddd, MMMM Do YYYY, h:mm a")
        }, this.clock())
      }, 500)
    }

      render(){
        const { value } = this.state;
          return(
              <div className="App">
              <div className="jumbotron">
                <div className="container">
                <Router>
            <div>
            <nav>
            <span className="links">
              <Link to='/createEmp'>Create New Employee</Link>
              </span>
              <span className="links">
              <Link to='/startShift'>Start A New Shift</Link>
              </span>
            </nav>
            <Nav/>
                  <div className="date">
                  {this.state.value}
                  </div>
          
               
                {/* <Route path='/createEmp' render={()=><CreateEmp position={this.state.position}/>}/> */}
                <Route path='/startShift' render={()=><StartShift/>}/>
                </div>
            </Router>
          </div>
              </div>
          </div>

          )
      }
    };

      export default App;