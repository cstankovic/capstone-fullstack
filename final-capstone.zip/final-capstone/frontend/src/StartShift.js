import React, { Component } from 'react';
import axios from 'axios';
import logo from './logo.svg';
import './App.css';
import 'antd/dist/antd.css';
import { Form, Table, Icon, Divider, Calendar, Row, Col, Layout} from 'antd';
import {BrowserRouter as Router, Link, Route, Switch} from 'react-router-dom';
import ShiftForm from './ShiftForm';
import ShiftList from './ShiftList';
import ListDisplay from './ListDisplay';
import Totals from './Totals';
import Nav from './Nav';
import CreateEmp from './CreateEmp';
const moment =require('moment');
  

const { Header, Footer, Sider, Content } = Layout;

class StartShift extends Component {
  constructor (){
    super();
    this.state ={
        employee:[],
        position:[],
        shift:[],
        totalTips: 0,
        totalPoints: 0,
        amtPerPoint: 0,
        selectedRowKeys:[],
        value: moment().format("dddd, MMMM Do YYYY, h:mm a"),
    }

    this.addToShift = this.addToShift.bind(this);
    this.calcTotals = this.calcTotals.bind(this);
    this.deleteEmp = this.deleteEmp.bind(this);
    this.onSelectChange = this.onSelectChange.bind(this);
    
  }

  componentDidMount(){
    axios.get('http://localhost:8080/positions')
    .then((results)=>{
      console.log(results)
      this.setState({
        position: results.data
      })
    })
    .catch((err)=>{
      console.log(err)
    })

    axios.get('http://localhost:8080/employees')
    .then((results)=>{
      console.log(results)
      this.setState({
        employee: results.data
      })
    })
    .catch((err)=>{
      console.log(err)
    })
  }


 calcTotals(){
  let pointsArr=[];
  let tipsArr=[];
  this.state.shift.map((curr, i)=>{
      pointsArr.push(curr.points);
      
      tipsArr.push(Number(curr.tipsEarned));
  })
    
  let totalPoints = pointsArr.reduce(function(accumulator, currVal) {
    return Number(accumulator + currVal)
  }, 0);

let totalTips = tipsArr.reduce(function(acc, currVal) {
    return Number(acc + currVal)
  }, 0);

  function precisionRound(number, precision) {
    var factor = Math.pow(10, precision);
    return Math.round(number * factor) / factor;
  }
  let amtPerPoint = precisionRound(totalTips / totalPoints, 2);



  this.setState({
    totalTips: totalTips, 
    totalPoints: totalPoints,
    amtPerPoint: amtPerPoint,
    delete: false
  }, this.calcPaid)
 }

calcPaid(){
  function precisionRound(number, precision) {
    var factor = Math.pow(10, precision);
    return Math.round(number * factor) / factor;
  }
  
  //this creates a copy of the statearray
   let newArray = this.state.shift.map((curr, i)=>{
     curr.tipsPaid = '$ ' + precisionRound(curr.points * this.state.amtPerPoint, 2)
     return curr;
  })
  this.setState({
    shift: newArray
  })
  
}

addToShift(emp){
  console.log(emp)

    const copyOfEmp = Object.assign({}, emp)
    copyOfEmp.key = this.state.shift.length
    let empCopy = Array.from(this.state.shift);
    
    axios.post('http://localhost:8080/submit', {emp: copyOfEmp})
    .then((result)=>{
      copyOfEmp.id=result.data.id
      empCopy.push(copyOfEmp);
      this.setState({
        shift: empCopy,
        value: moment().format("dddd, MMMM Do YYYY, h:mm a")}, this.calcTotals);
    })
    .catch(error =>{
      console.log(error)
    })
}

deleteEmp(){
  console.log('delete emp was hit')
    // make the DELETE request to server to delete employee

    // look at this.state.selectedRowKeuys
    //  this will tell us which iondexes in the 
    //  shift array that we should delete from the shift

    // 1. collexct all the ids of the employees
    //  we should remove from the shift
    let idsToDelete = [];
    let shiftPosition =[...this.state.selectedRowKeys];
    // let rowKeys = Array.from(this.state.selectedRowKeys);
    //     rowKeys.map((curr, i)=>{
    //      return shiftPosition.push(curr)
    // })
    let shiftCopy = Array.from(this.state.shift);
    for (let i = 0; i < shiftCopy.length; i++){
      for (let k = 0; k < shiftPosition.length; k++){
        if (shiftPosition[k] === shiftCopy[i].key){
          idsToDelete.push(shiftCopy[i])
        }
      }
    }
      //   shiftCopy.map((curr, i)=>{
      //     shiftPosition.map((val, j)=>{
      //       if (val === shiftCopy[i]){
      //         idsToDelete.push(shiftCopy[i])
      //       }
      //   })
      // })

  // loop0 over selectedRowKeys in sate
  // for each of the elements in that array, find the corresponding employee in shift array
  // and add their id to idsToDelete

    // 2. once we have the ids, hit the backend to remove them in the DB
    axios.delete('http://localhost:8080/clear', {data:{id: idsToDelete}})
      .then((result)=>{
          console.log('axios',result)
        // loop through this.state.selectedRowKeys
        //  each element in that array is one position
        //  we need to remove from the shift

        // in the .filter, keep the employee if the index that that employee lives at is NOT in te selectedRowKeys array

        // this.setState({shift:this.state.shift.filter((e,i)=>!this.state.selectedRowKeys.includes(i))}, this.calcTotals)
      })
      .catch(err =>{
        console.log(err)
      })
  this.setState({shift:this.state.shift.filter((e,i)=>!this.state.selectedRowKeys.includes(i))}, this.calcTotals)
};

onSelectChange(selectedRowKeys){
 
  // let shiftCopy = Array.from(this.state.shift);
  // shiftCopy.map((curr, i)=>{
  //   if(shiftCopy.newEmp === curr.newEmp){
  //    return shiftCopy[i].delete = !shiftCopy[i].delete
  //   }
  // })
  // this.setState({
  //   shift: shiftCopy
  // })
  this.setState({selectedRowKeys})
}




  render(){
    const { value } = this.state;
    return (
      <div>
       {/* <div>
          <Nav/>
        </div> */}
        {/* <Router>
          <div>
            <nav>
              <Link to='/'>Home</Link>
              <Link to ='/'
            </nav>
          </div> */}
            {/* <Router>
              <div>
              <nav>
                <Link to='/createEmp'>Create New Employee</Link>
              </nav>
                <Switch>
                  <Route path='/createEmp' render={()=><CreateEmp position={this.state.position}/>}/>
                </Switch>
                </div>
            </Router> */}
            <ShiftForm name={this.state.employee} position={this.state.position} formSubmit= {this.addToShift} />
            <div>
            <ListDisplay selectedRowKeys={this.state.selectedRowKeys} shift={this.state.shift} amtPerPoint={this.amtPerPoint} delete={this.delete} deleteEmp = {this.deleteEmp} onSelectChange={this.onSelectChange}/>
            <Totals style = {{position: 'fixed'}} totalTips = {this.state.totalTips} totalPoints = {this.state.totalPoints} amtPerPoint = {this.state.amtPerPoint} />
          
        </div>
      </div>
      
    )
  }

};

export default StartShift;
