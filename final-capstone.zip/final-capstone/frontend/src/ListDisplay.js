import React from 'react';
import { Form, Table, Icon, Divider, Button, Row, Col} from 'antd';
import './App.css';



class ListDisplay extends React.Component{
    render() {
        const columns = [{
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    width: '20%'
  }, {
    title: 'Position',
    dataIndex: 'position',
    key: 'position',
    width:'20%'
  }, {
    title: 'Points',
    dataIndex: 'points',
    key: 'points',
    width:'20%'
  }, {
    title: 'Tips Earned',
    dataIndex: 'tipsEarned',
    key: 'tipsEarned',
    width:'20%'
  }, {
    title: 'Tips Paid',
    dataIndex: 'tipsPaid',
    key: 'tipsPaid'
    }];

    const { selectedRowKeys } = this.props;
    const rowSelection ={
        selectedRowKeys,
        onChange: this.props.onSelectChange
            
        };
        return(
            <div style = {{background: 'OOccc', padding: '5vw'}}>
                
                <Table rowSelection={rowSelection} columns={columns} dataSource={this.props.shift} pagination={{ pageSize: 50 }} scroll={{ y: 240 }} />
                <div style = {{position: 'center'}}>
                <Row type="flex" justify="left">
                    <Col span={4} >
                <Button htmlType ="submit"
                        style={{marginTop: '1vw'}}
                        onClick={this.props.deleteEmp}
                        > Delete Selected Employee
                </Button>
                </Col>
                </Row>
                </div>
            </div>

        )
    }
};

export default ListDisplay;