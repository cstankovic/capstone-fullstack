import React, { Component } from 'react';
import logo from './header-logo.png';

class Nav extends React.Component{
    render(){
        return(
            <img src={logo} width="400vw" height="400vw" alt={"logo"} />
        )
    }
}
export default Nav;