import React from 'react';
import ListDisplay from './ListDisplay';
import './App.css';
// import Totals from 'Totals';


class ShiftList extends React.Component {
    render() {
        // let tipsPaid = this.props.shift.map((emp, i)=>{
        //     return Number(emp.points * this.props.amtPerPoint)
        // });
       let empListJSX = this.props.shift.map((emp, i)=>{
           let tipsEarned = this.props.amtPerPoint * emp.points
        return <ListDisplay key = {i}
                            name = {emp.name}
                            position = {emp.position}
                            points = {emp.points}
                            tipsEarned = {emp.tipsEarned} 
                            tipsPaid = {emp.tipsPaid}
                            selectedRowKeys={this.props.selectedRowKeys}
                            />
        })
    

        return(
            <ul>
            {empListJSX}
            </ul>
        )
    }
}


export default ShiftList;