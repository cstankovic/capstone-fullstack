import React from 'react';
import { Select, InputNumber, Row, Col, Form, Input, Cascader, Button } from 'antd';
import axios from 'axios';
import './App.css';



const Option = Select.Option;
const FormItem = Form.Item;
const InputGroup = Input.Group;

class CreateEmp extends React.Component{
    constructor(){
        super();
        this.state={

        }
        this.changeHandler = this.changeHandler.bind(this);
    }

    changeHandler=(value,key)=> {
        this.setState({
            [key]: value
        });
    }
    render(){
        let posList = this.props.position.map((curr, i)=>{
            return <Option key={curr.name}>{curr.name}</Option>
        })

        const formItemLayout = {
            labelCol: {
              xs: { span: 24 },
              sm: { span: 8 },
            },
            wrapperCol: {
              xs: { span: 24 },
              sm: { span: 16 },
            },
          };
          const configFirst = {
            rules: [{ type: 'string', required: true, message: 'First Name' }],
          };
          const configLast = {
            rules: [{ type: 'string', required: true, message: 'Last Name' }],
          };
          const configPosition = {
            rules: [{ required: true, message: 'Position' }],
          };

        return(
            <div>
            
           <Form layout="vertical" onSubmit={this.createEmpData}>
                <InputGroup>
                    <Row type="flex">
                        <Col span={6} offset={12}>
                            <FormItem style={{width:"100%"}}>
                                <Input label="First Name"/>
                               
                            </FormItem>
                        </Col>
                    </Row>
                    <Row type="flex">
                        <Col span={6} offset={12}>
                            <FormItem style={{width:"100%"}}>
                                <Input label="Last Name"/>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row type="flex">
                        <Col span={6} offset={12}>
                            <FormItem style={{width:"100%"}}>
                                <Select style={{width:"100%"}} size="large" label="Position" onChange={val=>this.changeHandler(val,'position')}>
                                {posList}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                </InputGroup>
         </Form>
         </div>
        )
    }
}

export default CreateEmp;