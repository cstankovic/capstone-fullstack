import React from 'react';
import { Card, Col, Row} from 'antd';
import './App.css';

class Totals extends React.Component{
    render(){
    
        return(
            <div style = {{background: 'OOccc', padding: '5vw'}} >
                <Row gutter ={20} >
                    <Col span={8}>
                        <Card title="Total Points in Pool" bordered={false}> {this.props.totalPoints}</Card>
                    </Col>
                    <Col span={8}>
                        <Card title="Total Tips in Pool" bordered={false}> $ {this.props.totalTips}</Card>
                    </Col>
                    <Col span={8}>
                        <Card title="Amount Per Point" bordered={false}> $ {this.props.amtPerPoint}</Card>
                    </Col>
                </Row>
             
            </div>

        )
    }
};

export default Totals;